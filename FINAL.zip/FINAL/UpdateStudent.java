package FINAL;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;

class UpdateStudent extends JFrame implements ActionListener{

    JFrame f;
    JLabel id,id1,id2,id3,id4,id5,id6,id7,id9,id10,id11,id12,id15,lab,lab1,lab2;
    JLabel heading;
    JTextField t,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14;
    JButton b,b1,b2; 
    String id_emp;

   public UpdateStudent(){;
        f=new JFrame("Update Student details");
        f.setSize(900,650);
        f.setLocation(450,150);
        f.setLayout(null);
        
        heading = new JLabel("Update Student Details:");
		 heading.setBounds(50,10,500,50);
		 heading.setFont(new Font("serif",Font.ITALIC,25));
		 heading.setForeground(Color.black);
		 f.add(heading);

        JLabel l1 = new JLabel("Enter Enrollment Number to update the data of student");
        l1.setBounds(50,100,500,30);
        f.add(l1);
        
        t12 = new JTextField();
        t12.setBounds(500,100,200,30);
        f.add(t12);
        
        b2 = new JButton("Search");
        b2.setBounds(720,100,100,30);
		b2.setBackground(new Color(245,255,250));

        f.add(b2);
        b2.addActionListener(this);

        
        


        id1 = new JLabel("Name");
        id1.setBounds(50,170,100,30);
        f.add(id1);

        t1=new JTextField();
        t1.setBounds(200,170,150,30);
        f.add(t1);

        id2 = new JLabel("DOB(YYYY/MM/DD) :");
        id2.setBounds(400,170,200,30);
        f.add(id2);

        t2=new JTextField();
        t2.setBounds(600,170,150,30);
        f.add(t2);

        id3= new JLabel("Admission type :");
        id3.setBounds(50,220,100,30);
        f.add(id3);

        t3=new JTextField();
        t3.setBounds(200,220,150,30);
        f.add(t3);

        id4= new JLabel("Gender(M/F/Oth) :");  
        id4.setBounds(400,220,200,30);
        f.add(id4);

        t4=new JTextField();
        t4.setBounds(600,220,150,30);
        f.add(t4);

        id5= new JLabel("Nationality :");
        id5.setBounds(50,270,100,30);
        f.add(id5);

        t5=new JTextField();
        t5.setBounds(200,270,150,30);
        f.add(t5);

        id6= new JLabel("Address :");
        id6.setBounds(400,270,100,30);
        f.add(id6);

        t6=new JTextField();
        t6.setBounds(600,270,150,30);
        f.add(t6);

        id7= new JLabel("Email-id :");
        id7.setBounds(50,320,100,30);
        f.add(id7);

        t7=new JTextField();
        t7.setBounds(200,320,150,30);
        f.add(t7);

        id9= new JLabel("Phone_no :");
        id9.setBounds(400,320,130,30);
        f.add(id9);

        t8=new JTextField();
        t8.setBounds(600,320,150,30);
        f.add(t8);

       
        
        b = new JButton("Save");
        b.setBounds(250,520,150,40);
		b.setBackground(new Color(245,255,250));

        f.add(b);

        b1=new JButton("Cancel");   
        b1.setBounds(450,520,150,40);
		b1.setBackground(new Color(245,255,250));

        
       // f.add(b1);
        
        Color  red  = new Color(255,228,225);
		f.getContentPane().setBackground(red);
        b.addActionListener(this);
        b1.addActionListener(this);
        
        f.setVisible(true);
    }



    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b){
            try{
                conne con = new conne();
                int n = Integer.parseInt(t8.getText());

                String str = "update student set name=' "+t1.getText()+" ',dob=' "+t2.getText()+" ',admmision_type=' "+t3.getText()+" ', gender=' "+t4.getText()+" ',nationality=' "+t5.getText()+" ',address=' "+t6.getText()+" ',email=' "+t7.getText()+" ',phone="+n+" where enrollment_no='"+t12.getText()+"'";
                
                int x = 0;
                x = con.s.executeUpdate(str);
                if(x !=0) {
                	JOptionPane.showMessageDialog(null,"successfully updated");
                }
                else {
                	JOptionPane.showMessageDialog(null,"not updated");

                }
               // f.setVisible(false);
               // new Add_Student();
            }catch(Exception e){
                System.out.println("The error is:"+e);
            }
        }
        
        if(ae.getSource() == b2){
            try{
                conne con = new conne();
                String str = "select * from student where enrollment_no = '"+t12.getText()+"'";
                ResultSet rs = con.s.executeQuery(str);

                if(rs.next()){
                    f.setVisible(true);
             

                    t1.setText(rs.getString(2));
                    t2.setText(rs.getString(3));
                    t3.setText(rs.getString(4));
                    t4.setText(rs.getString(5));
                    t5.setText(rs.getString(6));
                    t6.setText(rs.getString(7));
                    t7.setText(rs.getString(8));
                    t8.setText(rs.getString(9));
                }

                
            }catch(Exception ex){}
        
            f.setVisible(true);
            f.setSize(900,650);
            f.setLocation(450,250);
        }
    }

    public static void main(String[] arg){
        new UpdateStudent().f.setVisible(true);
    }
}

