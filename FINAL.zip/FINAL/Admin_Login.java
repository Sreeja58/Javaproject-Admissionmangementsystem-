package FINAL;

import java.sql.*;
import java.util.*;

import javax.swing.*;

import java.awt.Color;
import java.awt.event.*;

interface login{
	void admin_login();
}

public class Admin_Login implements ActionListener,login
{
	static JFrame a;
	static JLabel q,e;
	static JTextField us,pas;
	static JPasswordField passs;
	static JButton lg;
	Connection c = null;
	Statement stmt = null;
	ResultSet result = null;
	
	public static String ui,pa, pr= null;
	
	public Admin_Login()
	{
		Scanner sc= new Scanner(System.in);
		//System.out.println("Enter Username: ");
		//ui = sc.nextLine();
		//System.out.println("Enter Password: ");
		//pa = sc.nextLine();
		
		
		a = new JFrame("User Login ");
		
		q = new JLabel("USERNAME :");
		q.setBounds(100, 30, 90, 20);
		
		us = new JTextField();
		us.setBounds(100, 60, 90, 20);
		
		e = new JLabel("PASSWORD :");
		e.setBounds(100, 90, 90, 20);
		
		passs = new JPasswordField();
		//pas = new JTextField();
		passs.setBounds(100, 120, 90, 20);
		
		lg = new JButton("Login");
		lg.setBounds(100, 180, 90, 20);
		lg.setBackground(new Color(245,255,250));

		
		lg.addActionListener(this);
		
		a.add(q);a.add(us);a.add(e);a.add(passs);a.add(lg);
		
		Color  red  = new Color(255,228,225);
		a.getContentPane().setBackground(red);
		a.setLocation(500,250);
		a.setSize(300, 300);
		a.setLayout(null);
		a.setVisible(true);
		
		
	}

	public static void main(String[] args) 
	{
		new Admin_Login();
		
	}

	@Override
	public void actionPerformed(ActionEvent f)
	{
		admin_login();
		
	}

	@Override
	public void admin_login() {
		// TODO Auto-generated method stub
		ui = us.getText();
		pa = new String(passs.getPassword());
		
		try
		{
			Class.forName("org.postgresql.Driver");
			c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/JAVA PROJECT",
                    "postgres", "srita");
			stmt = c.createStatement();
			
			result = stmt.executeQuery("select pass from login where user_id ='"+ui+"';");
			
			while(result.next())
			{
				pr = result.getString(1);
			}	
		}
		
		catch (Exception e)
		{
			
			e.printStackTrace();
	        System.err.println(e.getClass().getName()+": "+e.getMessage());
	         System.exit(0);
		}
		
		try {
		if(pr.equals(pa))
		{
	   //  System.out.println("Login successfull :" +ui);
	     new Admin_Window(ui);
	     a.setVisible(false);
		}
		else {
		System.out.println("Password :" +pr);
		}
		}
		catch(NullPointerException e)
		{
			System.out.println("Wrong User Name");
		}
	}
		
	
}

