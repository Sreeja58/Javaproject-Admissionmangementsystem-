package FINAL;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

public class Payment extends Branch implements ActionListener
{
	JFrame f;
	JRadioButton p1,p2,p3,p4;
	
	JLabel heading;
	
	JButton pay;
	
	ButtonGroup pm ;
	public static int n =0;
	public static String pmd;

	public Payment(String j) 
	{
		f = new JFrame("Payment Method");
		
		heading = new JLabel("Payment Portals");
		 heading.setBounds(600,70,500,50);
		 heading.setFont(new Font("serif",Font.ITALIC,25));
		 heading.setForeground(Color.black);
		 f.add(heading);
		
		p1 = new JRadioButton("Net Banking");
		p1.setBounds(600, 140, 100, 30);
		p1.setBackground(new Color(240,248,255));
		
		p2 = new JRadioButton("Pay Pal");
		p2.setBounds(600, 210, 100, 30);
		p2.setBackground(new Color(240,248,255));
		
		p3 = new JRadioButton("Credit Card");
		p3.setBounds(600, 280, 100, 30);
		p3.setBackground(new Color(240,248,255));
		
		p4 = new JRadioButton("Debit  Card");
		p4.setBounds(600, 350, 100, 30);
		p4.setBackground(new Color(240,248,255));
		
		
		pm= new ButtonGroup();
		pm.add(p1);pm.add(p2);pm.add(p3);pm.add(p4);
		
		
		pay = new JButton("Pay Now");
		pay.setBounds(600, 400, 100, 30);
		pay.setBackground(new Color(245,255,250));

		
		
		f.add(p1);f.add(p2);f.add(p3);f.add(p4);
		f.add(pay);
		
		pay.addActionListener(this);
		
		Color  red  = new Color(255,228,225);
		f.getContentPane().setBackground(red);
		f.setSize(400, 400);
		f.setExtendedState(JFrame.MAXIMIZED_BOTH);
		f.setLayout(null);
		f.setVisible(true);
		
	}
	public Payment() {
		
	}


	@Override
	public void actionPerformed(ActionEvent e) 
	{
		
		if(p1.isSelected())
		{
			pmd = "Payment method selected is Net Banking";
			//System.out.println("Net Banking");
		}
		else if(p2.isSelected())
		{
			pmd = "Payment method selected is PayPal";
			//System.out.println("Pay Pal");
		}
		else if(p3.isSelected())
		{
			pmd = "Payment method selected is Credit Card";
			//System.out.println("Credit Card");
		}
		else if(p4.isSelected())
		{
			pmd = "Payment method selected is Debit Card";
			//System.out.println("Debit Card");
		}
	
		/* if (e.getActionCommand().equals("Click here")) { 
		     System.out.println("The selected radio button is: " + 
		              pm.getSelection().getActionCommand());
		     }*/
		
		      if(e.getSource() == pay)
				{
					new message();

		}
	
	}

	public static void main(String[] args) {
		new Payment(null);
	}
}






