package FINAL;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import javax.swing.*;

abstract class AL{
	abstract void delete_student();
	abstract void back_to_admin_page();
	
}

public class DeleteStudent extends AL implements ActionListener{
	JFrame f;
	JLabel l1;
	JTextField t1;
	JButton b1,back;
	
	Connection connect = null;
	Statement st = null;
	
	public static String q;
	
	public static int cr = 0;
	
	public DeleteStudent() {
		f = new JFrame("Delete Student");
		
		l1 = new JLabel("Enter Enrollment Number:");
		l1.setBounds(50,20,150,50);
		f.add(l1);
		
		t1 = new JTextField();
		t1.setBounds(50,70,200,40);
		f.add(t1);
		
		b1 = new JButton("Delete");
		b1.setBounds(260,70,100,50);
		b1.setBackground(new Color(245,255,250));

		f.add(b1);
		b1.addActionListener(this);
		
		back = new JButton("Back TO Admin Page");
		back.setBounds(50,130,200,30);
		back.addActionListener(this);
		back.setBackground(new Color(245,255,250));

		f.add(back);
		
		Color  red  = new Color(255,228,225);
		f.getContentPane().setBackground(red);
		f.setLayout(null);
		f.setSize(500,300);
		f.setVisible(true);
	}
	
	
	public static void main(String[] args) {
		new DeleteStudent();
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == b1) {
			
			delete_student();
			
			if(cr==0) {
				JOptionPane.showMessageDialog(f, "The entered Student data is not Deleted ");
			}
			else if(cr != 0 ){
				JOptionPane.showMessageDialog(f, "The student "+t1.getText()+" Is Deleted Successfully ");
			}
		}
		
		else if(e.getSource()==back) {
			back_to_admin_page(); 
		}
			
	}


	@Override
	void delete_student() {
		// TODO Auto-generated method stub
		try{
	    	  
			Class.forName("org.postgresql.Driver");
			connect = DriverManager.getConnection("jdbc:postgresql://localhost:5432/JAVA PROJECT",
                    "postgres", "srita");
            q = "DELETE FROM STUDENT WHERE enrollment_no = '" + t1.getText() + "' ;";
            st =connect.createStatement();
            cr = st.executeUpdate(q);
         
            
        }catch(Exception ee){
            System.out.println("The error is:"+ee);         
        }
	}


	@Override
	void back_to_admin_page() {
		// TODO Auto-generated method stub
		new Admin_Window(null);
		f.setVisible(false);
		f.dispose();
	}

}
