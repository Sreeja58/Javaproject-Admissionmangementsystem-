package FINAL;

import javax.swing.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.*;

interface connection{
	void upload_student_db();
}

public class Branch extends Add_Student implements ActionListener, connection
{
	JFrame frame;
	
	JPanel panel;
	
	JLabel label;
	
	JLabel heading;
	
	JComboBox cb,cb1,cb2,cb3;
	
	JButton b,b1,b2;
	
	static String x,y,z,w;
	static String er,q;
	
	Random ran = new Random();
    long first4 = (ran.nextLong() % 9000L) + 1000L;
    long first = Math.abs(first4);

	public Branch(String k) 
	{
		 frame =new JFrame("BranchDetails"); 
	     panel=new JPanel();
	     
	     heading = new JLabel("Select Preferences");
		 heading.setBounds(600,50,500,50);
		 heading.setFont(new Font("serif",Font.ITALIC,25));
		 heading.setForeground(Color.black);
		 frame.add(heading);
	     
	     label = new JLabel();          
	     label.setHorizontalAlignment(JLabel.CENTER);  
	     label.setSize(400,100);
	     
	     String Program[]={"Preference-1","EEE","ECE","CSE","CS_AI","EAC","ME","CE"}; 
	     
	     cb=new JComboBox(Program);    
	     cb.setBounds(600,120,190,20);  
	     frame.add(cb); 
	     
	     String Program1[]={"Preference-2","EEE","ECE","CSE","CS_AI","EAC","ME","CE"};        
	     cb1=new JComboBox(Program1);    
	     cb1.setBounds(600,220,190,20);  
	     frame.add(cb1);   
	     
	     String Program2[]={"Preference-3","EEE","ECE","CSE","CS_AI","EAC","ME","CE"};        
	     cb2=new JComboBox(Program2);    
	     cb2.setBounds(600,320,190,20);  
	     frame.add(cb2);
	     
	     String Program3[]={"Preference-4","EEE","ECE","CSE","CS_AI","EAC","ME","CE"};        
	     cb3=new JComboBox(Program3);    
	     cb3.setBounds(600,420,190,20);  
	     frame.add(cb3); 
	     
	    
	     
	 
	   //  frame.setLayout(null);    
	   //  frame.setSize(350,350);    
	   //  frame.setVisible(true); 
	     
	     b=new JButton("Save & Next");
		 b.setBounds(625,490,150, 20);       
		b.setBackground(new Color(245,255,250));

		 frame.add(b);
		 
		 
		 b.addActionListener(this);
		 
		// b1=new JButton("Edit"); 
		// b1.setBounds(140,400,100, 20);       
		// frame.add(b1);
		 
		 //b2=new JButton("Next");
		// b2.setBounds(200,400,100, 20);          
		// frame.add(b2);
		 
		 
		 Color  red  = new Color(255,228,225);
			frame.getContentPane().setBackground(red);
			frame.setSize(400,500);
			frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			frame.setLayout(null);
			frame.setVisible(true);
	}
	
	
	
	public void upload_student_db() {
		// TODO Auto-generated method stub
		x = (String)cb.getSelectedItem();
		  y = (String)cb1.getSelectedItem();
	      z = (String)cb2.getSelectedItem();
	      w = (String)cb3.getSelectedItem();
	      q = Long.toString(first);
	      er = "ER"+q;
	    		  
	      try{
	    	  
            conne cc = new conne();
            String q = "insert into student values('"+er+"','"+name+"','"+DOB+"','"+AT+"','"+gender+"','"+nation+"','"+address+"','"+email+"','"+phone+"','"+x+"','"+y+"','"+z+"','"+w+"')";
            cc.s.executeUpdate(q);
            JOptionPane.showMessageDialog(null,"Student Details Inserted Successfully");
            frame.setVisible(false);
        }catch(Exception ee){
            System.out.println("The error is:"+ee);
        }
	}
	
	
	
	public Branch() {
		
	}
	 public void actionPerformed(ActionEvent l){
		 
		 upload_student_db();
		 
	      new Payment(null);
	 }
	 
	 
	 
	 
	public static void main(String[] args)
	{
		new Branch(null);
		
		
	}


}

