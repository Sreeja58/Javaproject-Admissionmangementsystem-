package FINAL;
import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.*;
import java.sql.*;

interface stu_details{
	void dis_stu_table_details();
}

public class GetTabelFinal implements ActionListener,stu_details
{
	JFrame f;
	JTable jt;
	
	Connection c = null;
	Statement st = null;
	
	 String[][]  res;
	 
	 JButton back;
	

	public GetTabelFinal()
	{
		int x=0;
		try
		{
			Class.forName("org.postgresql.Driver");
			c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/JAVA PROJECT",
                    "postgres", "srita");
			st =c.createStatement();
			ResultSet r = st.executeQuery( "SELECT COUNT(*) FROM STUDENT;" );
			while(r.next())
			{
				x = r.getInt(1);
			}
			r.close();
		    res= new String[x][13];
		   // int j =x;
			ResultSet q = st.executeQuery( "SELECT * FROM STUDENT;" );
			//q.next();
			while(q.next())
			{
				
				
				for(int i =0;i<x;i++)
				{
					res[i][0]=q.getString(1);//ER
					res[i][1]=q.getString(2);//name
					res[i][2]=q.getString(3); //DOB
					res[i][3]=q.getString(4);//Admission type	
					res[i][4]=q.getString(5);//Gender
					res[i][5]=q.getString(6);//Nationality
					res[i][6]=q.getString(7);//Address
					res[i][7]=q.getString(8);//Email
					res[i][8]=q.getString(9);//Phone
					res[i][9]=q.getString(10);//preference
					res[i][10]=q.getString(11);
					res[i][11]=q.getString(12);
					res[i][12]=q.getString(13);
					
					//System.out.println(res[i][0] + "   "+ res[i][1]);
					//j++;
					//System.out.println("");
					q.next();
				}
			
			}
			
		
		
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
	         System.err.println(e.getClass().getName()+": "+e.getMessage());
	         System.exit(0);
		}
		
		/*for(int i =0;i<x;i++)
		{
			for(int j = 0;j<2;j++)
			{
				
			}
			
			System.out.println("");
			}
		
		System.out.println(res[0][0] +"   "+res[0][1]);
		System.out.println(res[1][0] +"   "+res[1][1]);
		System.out.println(res[2][0] +"   "+res[2][1]);
		System.out.println(res[3][0] +"   "+res[3][1]);
		//System.out.println("No. Of ROWS :"+x);
		*/
		
		f = new JFrame("All Students");
		String column[] = {"Enrolement No.","Name","DOB","Admission type","Gender","Nationality","Address","Email","Phone","Preference_1","Preference_2","Preference_3","Preference_4"};
		jt = new JTable(res,column);
		jt.setBounds(60, 80, 200, 300);
		
		JScrollPane sp = new JScrollPane(jt);
		
		back = new JButton("Back TO Admin Page");
		//back.setBounds(x, x, x, x);
		back.addActionListener(this);
		
		back.setBackground(new Color(245,255,250));

		Color  red  = new Color(255,228,225);
		f.getContentPane().setBackground(red);
		
		f.add(sp,BorderLayout.CENTER);
		f.add(back,BorderLayout.SOUTH);
		f.setSize(1300,800);
		f.setExtendedState(JFrame.MAXIMIZED_BOTH);
		f.setVisible(true);
		
	}

	public static void main(String[] args)
	{
		
           new GetTabelFinal();
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		dis_stu_table_details();
		
	}

	@Override
	public void dis_stu_table_details() {
		// TODO Auto-generated method stub
		new Admin_Window(null);
		f.setVisible(false);
		f.dispose();
	}

}
