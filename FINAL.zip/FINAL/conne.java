package FINAL;

import java.sql.*;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;

public class conne {
	Connection c;
	java.sql.Statement s;
	public conne() {
		
		try {
			Class.forName("org.postgresql.Driver");
			c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/JAVA PROJECT","postgres","srita");
			s = c.createStatement ();
			
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
}
