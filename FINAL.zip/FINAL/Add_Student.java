package FINAL;

import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;

abstract class AL1{
	abstract void setText();
	abstract void getText();
}


public class Add_Student extends AL1 implements ActionListener,KeyListener
{
	JFrame frame;
	
	JPanel panel;
	
	JLabel heading;
	
	JLabel xlabel,nlabel,dlabel,alabel,glabel,Nlabel,Alabel,elabel,plabel;
	JLabel nerr,aerr,gerr,Nerr,perr;
	
	JTextField xtext,ntext,dtext,atext,gtext,Ntext,Atext,etext,ptext;
	
	JButton b1,b2,b3;
	static String cg = "HELLOOOO vfrom add student ";
	
	static String name, DOB, AT, gender, nation, address,email ;
	static long phone;
	
	
	public Add_Student() {
		
	}
	
	
	
	public Add_Student(String s)
	{
		 frame=new JFrame("Enter Student Details");
		 panel=new JPanel();
		 
		 heading = new JLabel("Student Details");
		 heading.setBounds(650,70,500,50);
		 heading.setFont(new Font("serif",Font.ITALIC,25));
		 heading.setForeground(Color.black);
		 frame.add(heading);
		
		
		nlabel=new JLabel("Name :");
		nlabel.setBounds(600,140,80,25);
		panel.add(nlabel);
		
		ntext=new JTextField(20);
		ntext.setBounds(740,140,165,25);
		panel.add(ntext);
		
		nerr = new JLabel();
		nerr.setBounds(910,140,100,25);
		panel.add(nerr);
		
		
		dlabel=new JLabel("DOB(YYYY/MM/DD) :");
		dlabel.setBounds(600,170,120,25);
		panel.add(dlabel);
		
		dtext=new JTextField(20);
		dtext.setBounds(740,170,165,25);
		panel.add(dtext);
		
		
		
		alabel=new JLabel("Admission type :");
		alabel.setBounds(600,200,200,25);
		panel.add(alabel);
		
		atext=new JTextField(20);
		atext.setBounds(740,200,165,25);
		panel.add(atext);
		
		aerr = new JLabel();
		aerr.setBounds(910,200,100,25);
		panel.add(aerr);

		
		
		panel.setLayout(null);
		//frame.setVisible(true);
		
		glabel=new JLabel("Gender(M/F/Oth) :");
		glabel.setBounds(600,230,80,25);
		panel.add(glabel);
	
        gtext=new JTextField(20);
		gtext.setBounds(740,230,20,20);
		panel.add(gtext);
		
		gerr = new JLabel();
		gerr.setBounds(910,230,100,25);
		panel.add(gerr);
		
		//frame.setVisible(true);
		
		Nlabel=new JLabel("Nationality :");
		Nlabel.setBounds(600,260,165,25);
	    panel.add(Nlabel);
	    
		Ntext=new JTextField(20);
		Ntext.setBounds(740,260,165,25);
		panel.add(Ntext);
		
		Nerr = new JLabel();
		Nerr.setBounds(910,260,100,25);
		panel.add(Nerr);
		
		
		Alabel=new JLabel("Address :");
		Alabel.setBounds(600,290,80,25);
		panel.add(Alabel);
		
		Atext=new JTextField(20);
		Atext.setBounds(740,290,165,40);
		panel.add(Atext);
		
		elabel=new JLabel("Email-id :");
		elabel.setBounds(600,340,80,25);
		panel.add(elabel);
		
		etext=new JTextField(20);
		etext.setBounds(740,340,165,25);
		panel.add(etext);
						
		plabel=new JLabel("Phone_no :");
		plabel.setBounds(600,380,80,25);
		panel.add(plabel);
		
		ptext=new JTextField(20);
		ptext.setBounds(740,380,165,25);
		panel.add(ptext);
		
		perr = new JLabel();
		perr.setBounds(910,380,100,25);
		panel.add(perr);
		
		b1=new JButton("Reset");
		b1.setBounds(600,410,80,25);
		b1.setBackground(new Color(245,255,250));

		panel.add(b1);
					 
		b2=new JButton("Next");
		b2.setBounds(700,410,130,25);
		b2.setBackground(new Color(245,255,250));

	    panel.add(b2); 
	
		//b3=new JButton("Next");
		//b3. setBounds(210,310,80, 25);          
		//panel.add(b3);
		panel.setVisible(true);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		//b3.addActionListener(this);
		
		ntext.addKeyListener(this);
		dtext.addKeyListener(this);
		atext.addKeyListener(this);
		gtext.addKeyListener(this);
		Ntext.addKeyListener(this);
		Atext.addKeyListener(this);
		etext.addKeyListener(this);
		ptext.addKeyListener(this);
		
		
		frame.add(panel);

		 Color  red  = new Color(255,228,225);
		panel.setBackground(red);
		 frame.setSize(500,400);
		 frame.setVisible(true);
		 frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		 
		
	}
	
	
	public static void main(String[] args) 
	{
		new Add_Student(null);
					
	}

	
	void setText() {
		// TODO Auto-generated method stub
		ntext.setText("");
		dtext.setText("");
		atext.setText("");
		gtext.setText("");
		Ntext.setText("");
		Atext.setText("");
		etext.setText("");
		ptext.setText("");
	}



	@Override
	void getText() {
		// TODO Auto-generated method stub
		name    = ntext.getText();
		DOB     = dtext.getText();
		AT      = atext.getText();
		gender  = gtext.getText();
		nation  = Ntext.getText();
		address = Atext.getText();
		email   = etext.getText();
		phone = Long.parseLong(ptext.getText());
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == b1)
		{
			setText();
		}
		
		else if(e.getSource() == b2)
		{
			getText();
		
			
			
			new Branch(null);
		}
		
		
		// TODO Auto-generated method stub
		
	}


   public void keyReleased(KeyEvent f) 
   {
	   String get;
	   String n = "!!!!!";
	   if(f.getSource() == ntext || f.getSource() == atext || f.getSource() == Ntext || f.getSource() == gtext )
	   {
		   if(f.getSource() == ntext)
		   {
			   get = ntext.getText();
			   for (int i = 0; i < get.length(); i++)
		        {
		            char c = get.charAt(i);
		            if (!(c >= 'A' && c <= 'Z') && !(c >= 'a' && c <= 'z'))
		            {
		                nerr.setText(n);
		            }
		            else
		            {
		            	nerr.setText("");
		           }
		        }
		   }
		   
		   if(f.getSource() == atext)
		   {
			   get = atext.getText();
			   for (int i = 0; i < get.length(); i++)
		        {
		            char c = get.charAt(i);
		            if (!(c >= 'A' && c <= 'Z') && !(c >= 'a' && c <= 'z'))
		            {
		                aerr.setText(n);
		            }
		            else
		            {
		            	aerr.setText("");
		            }
		        }
		   }
		   if(f.getSource() == Ntext)
		   {
			   get = Ntext.getText();
			   for (int i = 0; i < get.length(); i++)
		        {
		            char c = get.charAt(i);
		            if (!(c >= 'A' && c <= 'Z') && !(c >= 'a' && c <= 'z'))
		            {
		                Nerr.setText(n);
		            }
		            else
		            {
		            	Nerr.setText("");
		            }
		        }
		   }
		   if(f.getSource() == ntext)
		   {
			   get = ntext.getText();
			   for (int i = 0; i < get.length(); i++)
		        {
		            char c = get.charAt(i);
		            if (!(c >= 'A' && c <= 'Z') && !(c >= 'a' && c <= 'z'))
		            {
		                nerr.setText(n);
		            }
		            else
		            {
		            	nerr.setText("");
		            }
		        }
		   }
		   if(f.getSource() == gtext)
		   {
			   get = gtext.getText();
			   for (int i = 0; i < get.length(); i++)
		        {
		            char c = get.charAt(i);
		            if (!(c >= 'A' && c <= 'Z') && !(c >= 'a' && c <= 'z'))
		            {
		                gerr.setText(n);
		            }
		            else
		            {
		            	gerr.setText("");
		            }
		        }
		   }
	   }
	   else if(f.getSource() == ptext)
	   {
		   get = ptext.getText();
		   for (int i = 0; i < get.length(); i++)
	        {
	            char c = get.charAt(i);
	            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))
	            {
	                perr.setText(n);
	            }
	            else
	            {
	            	perr.setText("");
	            }
	        }
	   }
	   
		   
   }
	public void keyTyped(KeyEvent f){}
	public void keyPressed(KeyEvent f) {}

	
	}