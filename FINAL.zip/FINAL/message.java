package FINAL;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
 
public class message extends Payment implements ActionListener{
	JFrame f;
	JLabel p1,p2;
	message(){
		f = new JFrame("Payment Status");
		p1 = new JLabel("Payment Successful !!!!!!");
		p1.setBounds(50,25,150,30);
		f.add(p1);
		
		p2 = new JLabel("Your Enrollment number is : " + er);
		p2.setBounds(50,100,250,30);
		f.add(p2);
		
		
		Color  red  = new Color(255,228,225);
		f.getContentPane().setBackground(red);
		f.setLocation(500,250);
		f.setLayout(null);
		f.setSize(300,300);
		f.setVisible(true);
	}
	
	
	public static void main(String[] args) {
		new message();
	}
}