package FINAL;

import java.sql.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;

import java.awt.event.*;
import java.awt.*;


interface gui{
	void display_admin();
	void display_student_form();
	
}

public class Start implements ActionListener,gui
{
	static JFrame f;
	static JLabel head;
	static JPanel pan; 
	
	static JButton admin,enroll,check;
	
	
	
	public Start()
	{

		
		
		f = new JFrame("ADMISSIONS PAGE");
		
		head = new JLabel("Namah Shivaya");
		
		
		//pan = new JPanel();
		
		//BoxLayout box = new BoxLayout(pan,BoxLayout.Y_AXIS); 
		
		//pan.setLayout(box);
		//pan.setBorder(new EmptyBorder(new Insets(150,200,150,200)));
		
		
		enroll = new JButton("Enroll As Student");
		enroll.setBounds(65, 70, 150, 25);
		enroll.setBackground(new Color(245,255,250));
		
		admin = new JButton("Admin");
		admin.setBounds(55, 130, 170, 25);
		admin.setBackground(new Color(240,248,255));
		
		admin.addActionListener(this);
		enroll.addActionListener(this);
		
		
		f.add(enroll);
		
		f.add(admin);
		
		Color  red  = new Color(255,228,225);
		
		
		
		f.setSize(300,300);
		f.setLocation(500,250);
		f.setLayout(null);
		f.getContentPane().setBackground(red);
		f.setVisible(true);
		
		
		
	}
	
	
	public static void main(String[] args)
	{
		new Start();
	}

	
	//Interface implemented
	public void display_admin() {
		//System.out.println("HELLO");
		new Admin_Login();
		f.setVisible(false);
	}

	//Interface implemented
	public void display_student_form() {
		new Add_Student(null);
		f.setVisible(false);	
	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == admin)
		{
			//System.out.println("WOrking");
			display_admin();
			//Admin_Login.setVisible(true);
		
		}
		else if(e.getSource() == enroll)
		{
			//System.out.println("WOrking");
			display_student_form();
			
		}
		
	}

}

