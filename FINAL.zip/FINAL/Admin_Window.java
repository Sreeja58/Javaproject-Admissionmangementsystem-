package FINAL;

import java.awt.Color;
import java.awt.event.*;

import javax.swing.*;


public class Admin_Window implements ActionListener
{
	
	 JFrame f;
	  JLabel head;
	  JPanel pan; 
	
	  JButton ad,upds,del,all;
	
	
	public Admin_Window(String a)
	{
		f= new JFrame("Logged in as "+a);
		
		ad = new JButton("Add Student");
		ad.setBounds(600,140, 150, 30);
		ad.setBackground(new Color(245,255,250));

		
		
		upds  = new JButton("Update Student");
		upds.setBounds(600, 200, 150, 30);
		upds.setBackground(new Color(245,255,250));

		
		del = new JButton("Delete Student");
		del.setBounds(600, 260, 150, 30);
		del.setBackground(new Color(245,255,250));

		
		all = new JButton("Display All Student Enrolled");
		all.setBounds(525, 320, 350, 30);
		all.setBackground(new Color(245,255,250));

		
		f.add(ad);
		f.add(upds);
		f.add(del);
		f.add(all);
		
		ad.addActionListener(this);
		upds.addActionListener(this);
		del.addActionListener(this);
		all.addActionListener(this);
		
		Color  red  = new Color(255,228,225);
		f.getContentPane().setBackground(red);
		f.setExtendedState(JFrame.MAXIMIZED_BOTH);
		f.setSize(500,400);
		f.setLayout(null);
		f.setVisible(true);
		
		
	}
	
	public static void main(String[] args )
	{
		new Admin_Window(null);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == ad)
		{
			new Add_Student(null);
			f.setVisible(false);
			
		}
		
		else if(e.getSource() == upds)
		{
			new UpdateStudent();
			
		}
		
		else if(e.getSource() == del)
		{
			new DeleteStudent();
		}
		
		else if(e.getSource() == all)
		{
			new GetTabelFinal();
			f.setVisible(false);
		}
		
		
	}
	
}

